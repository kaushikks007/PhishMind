@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0backend"

if not exist ".venv\Scripts\pythonw.exe" (
    echo [PhishMind] No virtual environment found in backend\.venv
    echo.
    echo Run setup first, from the backend folder:
    echo     python -m venv .venv
    echo     .venv\Scripts\activate
    echo     pip install -r requirements.txt
    exit /b 1
)

if not exist ".env" (
    echo [PhishMind] backend\.env not found.
    echo Copy .env.example to .env and fill in your GEMINI_API_KEY
    echo ^(and IMAP_HOST / IMAP_USERNAME / IMAP_APP_PASSWORD to auto-watch your inbox^).
    exit /b 1
)

if exist "phishmind.pid" (
    set /p OLDPID=<phishmind.pid
    tasklist /FI "PID eq !OLDPID!" 2>nul | find "!OLDPID!" >nul
    if not errorlevel 1 (
        echo [PhishMind] Already running ^(PID !OLDPID!^). Run stop_phishmind.bat first if you want to restart it.
        exit /b 1
    )
)

echo [PhishMind] Starting in the background...

for /f "usebackq delims=" %%P in (`powershell -NoProfile -Command "$p = Start-Process -FilePath '.venv\Scripts\pythonw.exe' -ArgumentList '-m','uvicorn','main:app','--host','0.0.0.0','--port','8000' -WindowStyle Hidden -PassThru -RedirectStandardOutput 'phishmind_out.log' -RedirectStandardError 'phishmind_err.log'; $p.Id"`) do set PMPID=%%P

if "!PMPID!"=="" (
    echo [PhishMind] Failed to start. Check backend\phishmind_err.log for details.
    exit /b 1
)

echo !PMPID!> phishmind.pid

echo [PhishMind] Running silently in the background ^(PID !PMPID!^).
echo [PhishMind] It will keep scanning your inbox even with this window closed.
echo [PhishMind] Logs: backend\phishmind_out.log and backend\phishmind_err.log
echo [PhishMind] Dashboard: run "npm run dev" in the frontend folder, then open the URL it prints.
echo [PhishMind] To stop it: run stop_phishmind.bat
endlocal
