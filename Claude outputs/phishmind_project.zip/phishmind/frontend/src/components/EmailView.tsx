import type { ScanResult } from '../types';
import { cn } from '../lib/utils';
import { ShieldCheck, ShieldAlert } from 'lucide-react';

export default function EmailView({ email }: { email: ScanResult }) {
  const isSuspicious = email.verdict === 'SUSPICIOUS' || email.verdict === 'PHISHING';
  const bannerColor = email.verdict === 'PHISHING' ? 'bg-danger' : 'bg-suspicious';
  const isTranslated = !!email.translated_body && email.detected_language && email.detected_language !== 'en';
  const displaySubject = isTranslated && email.translated_subject ? email.translated_subject : email.subject;
  const displayBody = isTranslated ? email.translated_body! : email.body;

  return (
    <div className="flex-1 flex flex-col overflow-y-auto bg-background">
      {isSuspicious && (
        <div className={cn("p-4 text-white animate-in slide-in-from-top-4", bannerColor)}>
          <div className="font-bold flex items-center gap-2">
            <ShieldAlert className="w-5 h-5" />
            Warning: {email.verdict} (Score: {email.risk_score})
          </div>
          <div className="text-sm opacity-90 mt-1">{email.explanation}</div>
        </div>
      )}
      
      <div className="p-8 max-w-4xl mx-auto w-full">
        <div className="border-b border-border pb-6 mb-6">
          <h2 className="text-2xl font-bold mb-4">{displaySubject}</h2>
          <div className="flex items-center gap-3 flex-wrap">
            <div className="font-medium">{email.sender}</div>
            {email.claimed_brand && email.is_brand_verifiable === false && (
              <div className="flex items-center gap-1 text-xs px-2 py-1 rounded-full border bg-muted/10 text-muted-foreground border-border">
                <ShieldAlert className="w-3 h-3" />
                {`Unable to verify: claims to be ${email.claimed_brand} (sender info missing)`}
              </div>
            )}
            {email.claimed_brand && email.is_brand_verifiable !== false && (
              <div className={cn(
                "flex items-center gap-1 text-xs px-2 py-1 rounded-full border",
                email.is_brand_verified
                  ? "bg-safe/10 text-safe border-safe/20"
                  : "bg-danger/10 text-danger border-danger/20"
              )}>
                {email.is_brand_verified ? <ShieldCheck className="w-3 h-3" /> : <ShieldAlert className="w-3 h-3" />}
                {email.is_brand_verified ? `Verified: ${email.claimed_brand}` : `Spoofed: claims to be ${email.claimed_brand}`}
              </div>
            )}
            {isTranslated && (
              <div className="flex items-center gap-1 text-xs px-2 py-1 rounded-full border bg-indigo-500/10 text-indigo-300 border-indigo-500/20">
                Translated from {email.detected_language?.toUpperCase()} to English
              </div>
            )}
          </div>
        </div>

        <div className="whitespace-pre-wrap font-mono text-sm bg-surface p-6 rounded-lg border border-border overflow-x-auto">
          {displayBody}
        </div>

        {isTranslated && (
          <details className="mt-4">
            <summary className="cursor-pointer text-xs text-muted-foreground select-none">
              Show original ({email.detected_language?.toUpperCase()})
            </summary>
            <div className="whitespace-pre-wrap font-mono text-xs bg-surface/60 p-6 rounded-lg border border-border overflow-x-auto mt-2 text-muted-foreground">
              <div className="font-bold mb-2">{email.subject}</div>
              {email.body}
            </div>
          </details>
        )}
      </div>
    </div>
  );
}
