"""
Real-time inbox scanning via IMAP IDLE. Runs in a background thread (IMAP
IDLE is a blocking protocol), parses each new message through the exact same
pipeline as a manual scan, stores the result, and pushes it onto a
thread-safe queue that the SSE endpoint (/api/v1/listener/events) drains for
the frontend's live demo view.

Never crashes the server: all IMAP/network errors are caught and logged, and
the listener reports itself as stopped with a reason rather than killing the
process.
"""
from __future__ import annotations

import logging
import queue
import threading
import time

from imapclient import IMAPClient

from app.config import settings
from app.db.database import save_scan_result
from app.notifications import notify_scan_result
from app.parsing.email_parser import parse_eml_bytes
from app.pipeline import run_pipeline

logger = logging.getLogger("phishmind.imap_listener")


class ListenerState:
    """Thread-safe singleton tracking the background IMAP listener."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self.running = False
        self.username: str | None = None
        self.last_error: str | None = None
        self._thread: threading.Thread | None = None
        self._stop_event = threading.Event()
        self.events: "queue.Queue[dict]" = queue.Queue()

    def status(self) -> dict:
        with self._lock:
            return {
                "running": self.running,
                "username": self.username,
                "last_error": self.last_error,
            }

    def start(self, host: str, username: str, app_password: str) -> None:
        with self._lock:
            if self.running:
                raise RuntimeError("Listener is already running. Stop it before starting a new one.")
            self._stop_event.clear()
            self.running = True
            self.username = username
            self.last_error = None
            self._thread = threading.Thread(
                target=self._run,
                args=(host, username, app_password),
                daemon=True,
            )
            self._thread.start()

    def stop(self) -> None:
        with self._lock:
            self._stop_event.set()
            self.running = False

    def _run(self, host: str, username: str, app_password: str) -> None:
        try:
            with IMAPClient(host) as client:
                client.login(username, app_password)
                client.select_folder("INBOX")
                logger.info("PhishMind background guard active for %s", username)

                while not self._stop_event.is_set():
                    try:
                        messages = client.search(["UNSEEN"])
                        if messages:
                            for msg_id, data in client.fetch(messages, ["RFC822"]).items():
                                raw_message = data.get(b"RFC822")
                                if not raw_message:
                                    continue
                                self._handle_message(raw_message)
                    except Exception:
                        logger.exception("Error while polling inbox; will retry")
                    time.sleep(3)
        except Exception as exc:
            logger.exception("IMAP listener failed to start/run")
            with self._lock:
                self.running = False
                self.last_error = str(exc)

    def _handle_message(self, raw_message: bytes) -> None:
        try:
            email_data = parse_eml_bytes(raw_message)
            result = run_pipeline(email_data)
            scan_id = save_scan_result(result, source="imap_live")
            result["id"] = str(scan_id)
            self.events.put(result)
            if settings.desktop_notifications:
                notify_scan_result(result)
            logger.info(
                "New mail scanned: %s -> %s (%s/100)",
                result.get("subject", ""),
                result.get("verdict"),
                result.get("risk_score"),
            )
        except Exception:
            logger.exception("Failed to process incoming message")


listener_state = ListenerState()
