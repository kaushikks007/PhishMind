@echo off
setlocal
cd /d "%~dp0backend"

if not exist "phishmind.pid" (
    echo [PhishMind] Not running ^(no phishmind.pid found^).
    exit /b 0
)

set /p PMPID=<phishmind.pid

tasklist /FI "PID eq %PMPID%" 2>nul | find "%PMPID%" >nul
if errorlevel 1 (
    echo [PhishMind] Process %PMPID% is not running ^(already stopped^). Cleaning up.
    del phishmind.pid
    exit /b 0
)

echo [PhishMind] Stopping PhishMind ^(PID %PMPID%^)...
taskkill /PID %PMPID% /F >nul 2>&1
del phishmind.pid
echo [PhishMind] Stopped.
endlocal
